create
    definer = root@localhost procedure Insert_Customer(IN nameInput varchar(255), IN addressInput varchar(255))
BEGIN
    INSERT INTO customers(name,address) VALUES (nameInput,addressInput);
END;

